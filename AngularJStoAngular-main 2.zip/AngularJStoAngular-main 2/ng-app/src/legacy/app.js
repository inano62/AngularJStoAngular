
angular
  .module('legacyApp', [])
  .run(() => console.log('legacyApp running'));
