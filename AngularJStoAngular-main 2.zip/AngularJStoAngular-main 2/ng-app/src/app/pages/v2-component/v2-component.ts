import { Component } from '@angular/core';

@Component({
  selector: 'app-v2-component',
  imports: [],
  templateUrl: './v2-component.html',
  styleUrl: './v2-component.scss',
})
export class V2Component {

}
