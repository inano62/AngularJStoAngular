import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

@Component({
  selector: 'app-compnent',
  standalone: true,
  templateUrl: './app-compnent.html',
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AppCompnent {}
