import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div id="legacy-root"></div>`,

})
export class App {}
