import { Component } from '@angular/core';

@Component({
  selector: 'app-legacy-host',
  templateUrl: './legacy-host.component.html',
})
export class LegacyHostComponent {}
